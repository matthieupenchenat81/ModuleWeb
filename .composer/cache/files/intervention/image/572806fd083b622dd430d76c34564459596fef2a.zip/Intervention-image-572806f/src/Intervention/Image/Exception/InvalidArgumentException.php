<?php

namespace Intervention\Image\Exception;

class InvalidArgumentException extends \RuntimeException
{
    # nothing to override
}
