<?php

require __DIR__ . '/PhpParser/Autoloader.php';
PhpParser\Autoloader::register();