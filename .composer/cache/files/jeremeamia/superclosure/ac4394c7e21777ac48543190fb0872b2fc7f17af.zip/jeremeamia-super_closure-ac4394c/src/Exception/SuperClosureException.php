<?php namespace SuperClosure\Exception;

/**
 * This is a marker exception for the SuperClosure library.
 */
interface SuperClosureException
{
    //
}
